package com.model.onlinebank;

public class Login {
	
	private String custID;
	private String password;
	private String status;	
	public String getCustID() {
		return custID;
	}
	public void setCustID(String custID) {
		this.custID = custID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Login() {
		super();
	}
	
	
	
	 
}
