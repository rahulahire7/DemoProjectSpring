package com.controller.onlinebank;

public class GlobalController {

}
